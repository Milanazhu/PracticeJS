//Задача 1 Функция которая принимает три числа в качестве аргументом и возвращает их среднее значение
function num(a, b, c) {
    let average = (a+b+c)/3;
    return average;
}
num();

const result = num(3,3,3);
console.log(result);
